package com.example.datn.Reponsitory;

import com.example.datn.Entity.CoaoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CoaoEntityRepository extends JpaRepository<CoaoEntity, Integer> {
}