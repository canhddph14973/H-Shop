package com.example.datn.Reponsitory;

import com.example.datn.Entity.ChatlieuEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChatlieuEntityRepository extends JpaRepository<ChatlieuEntity, Integer> {
}