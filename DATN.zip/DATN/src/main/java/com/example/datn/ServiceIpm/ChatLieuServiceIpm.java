package com.example.datn.ServiceIpm;

import java.util.List;
import java.util.Optional;
import com.example.datn.Entity.ChatlieuEntity;
public interface ChatLieuServiceIpm {
    List<ChatlieuEntity> findAll();

    List<ChatlieuEntity> findAllById(Iterable<Integer> integers);

    <S extends ChatlieuEntity> S save(S entity);

    Optional<ChatlieuEntity> findById(Integer integer);

    void deleteById(Integer integer);
}
