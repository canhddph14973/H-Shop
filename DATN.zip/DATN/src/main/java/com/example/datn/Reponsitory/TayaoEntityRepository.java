package com.example.datn.Reponsitory;

import com.example.datn.Entity.TayaoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TayaoEntityRepository extends JpaRepository<TayaoEntity, Integer> {
}