package com.example.datn.ServiceIpm;

import com.example.datn.Entity.HoatietEntity;

import java.util.List;
import java.util.Optional;

public interface HoaTietServiceIpm {
    List<HoatietEntity> findAll();

    List<HoatietEntity> findAllById(Iterable<Integer> integers);

    <S extends HoatietEntity> S save(S entity);

    Optional<HoatietEntity> findById(Integer integer);

    void deleteById(Integer integer);
}
