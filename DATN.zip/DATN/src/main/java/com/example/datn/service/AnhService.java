package com.example.datn.service;

import com.example.datn.Entity.AnhEntity;
import com.example.datn.Reponsitory.AnhEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.datn.ServiceIpm.AnhServiceIpm;

import java.util.List;
import java.util.Optional;

@Service
public class AnhService implements AnhServiceIpm{
    @Autowired
    AnhEntityRepository anhEntityRepository;

    @Override
    public List<AnhEntity> findAll() {
        return anhEntityRepository.findAll();
    }

    @Override
    public List<AnhEntity> findAllById(Iterable<Integer> integers) {
        return anhEntityRepository.findAllById(integers);
    }

    @Override
    public <S extends AnhEntity> S save(S entity) {
        return anhEntityRepository.save(entity);
    }

    @Override
    public Optional<AnhEntity> findById(Integer integer) {
        return anhEntityRepository.findById(integer);
    }

    @Override
    public void deleteById(Integer integer) {
        anhEntityRepository.deleteById(integer);
    }
}
