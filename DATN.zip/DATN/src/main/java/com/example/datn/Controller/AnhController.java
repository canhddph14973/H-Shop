package com.example.datn.Controller;

import com.example.datn.Entity.AnhEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.example.datn.ServiceIpm.AnhServiceIpm;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/Anh")
public class AnhController {
    @Autowired
    AnhServiceIpm anhServiceIpm;

    @GetMapping("")
    public List<AnhEntity> list(){
        return anhServiceIpm.findAll();
    }

    @PostMapping("")
    public AnhEntity Add(@RequestBody AnhEntity anhEntity){
        return anhServiceIpm.save(anhEntity);
    }
    @GetMapping("/{id}")
    public Optional<AnhEntity> getId(@PathVariable("id") int id ){
        return anhServiceIpm.findById(id);
    }
    @PutMapping("/{id}")
    public AnhEntity update(@PathVariable("id") int id,@RequestBody AnhEntity anhEntity){
        return anhServiceIpm.save(anhEntity);
    }
    @DeleteMapping("/deleteAnh/{id}")
    public void delete(@PathVariable("id") int id){
        anhServiceIpm.deleteById(id);
    }
}
