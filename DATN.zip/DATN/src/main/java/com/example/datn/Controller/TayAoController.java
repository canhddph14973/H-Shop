package com.example.datn.Controller;

import com.example.datn.Entity.TayaoEntity;
import com.example.datn.ServiceIpm.TayAoServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@RestController
@RequestMapping("/TayAo")
public class TayAoController {
    @Autowired
    TayAoServiceIpm TayAoServiceIpm;

    @GetMapping("")
    public List<TayaoEntity> list(){
        return TayAoServiceIpm.findAll();
    }

    @PostMapping("")
    public TayaoEntity Add(@RequestBody TayaoEntity TayaoEntity){
        return TayAoServiceIpm.save(TayaoEntity);
    }
    @GetMapping("/{id}")
    public Optional<TayaoEntity> getId(@PathVariable("id") int id ){
        return TayAoServiceIpm.findById(id);
    }
    @PutMapping("/{id}")
    public TayaoEntity update(@PathVariable("id") int id,@RequestBody TayaoEntity TayaoEntity){
        return TayAoServiceIpm.save(TayaoEntity);
    }
    @DeleteMapping("/deleteAnh/{id}")
    public void delete(@PathVariable("id") int id){
        TayAoServiceIpm.deleteById(id);
    }

}
