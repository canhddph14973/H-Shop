package com.example.datn.ServiceIpm;

import com.example.datn.Entity.MausacEntity;

import java.util.List;
import java.util.Optional;

public interface MauSacServiceIpm {
    List<MausacEntity> findAll();

    List<MausacEntity> findAllById(Iterable<Integer> integers);

    <S extends MausacEntity> S save(S entity);

    Optional<MausacEntity> findById(Integer integer);

    void deleteById(Integer integer);
}
