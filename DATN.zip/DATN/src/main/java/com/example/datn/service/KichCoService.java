package com.example.datn.service;

import com.example.datn.Entity.KichcoEntity;
import com.example.datn.Reponsitory.KichcoEntityRepository;
import com.example.datn.ServiceIpm.KichCoServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class KichCoService implements KichCoServiceIpm {
    @Autowired
    KichcoEntityRepository KichcoEntityRepository;

    @Override
    public List<KichcoEntity> findAll() {
        return KichcoEntityRepository.findAll();
    }

    @Override
    public List<KichcoEntity> findAllById(Iterable<Integer> integers) {
        return KichcoEntityRepository.findAllById(integers);
    }

    @Override
    public <S extends KichcoEntity> S save(S entity) {
        return KichcoEntityRepository.save(entity);
    }

    @Override
    public Optional<KichcoEntity> findById(Integer integer) {
        return KichcoEntityRepository.findById(integer);
    }

    @Override
    public void deleteById(Integer integer) {
        KichcoEntityRepository.deleteById(integer);
    }
}
