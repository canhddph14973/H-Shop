package com.example.datn.ServiceIpm;

import com.example.datn.Entity.KichcoEntity;

import java.util.List;
import java.util.Optional;

public interface KichCoServiceIpm {
    List<KichcoEntity> findAll();

    List<KichcoEntity> findAllById(Iterable<Integer> integers);

    <S extends KichcoEntity> S save(S entity);

    Optional<KichcoEntity> findById(Integer integer);

    void deleteById(Integer integer);
}
