package com.example.datn.service;

import com.example.datn.Entity.MausacEntity;
import com.example.datn.Reponsitory.MausacEntityRepository;
import com.example.datn.ServiceIpm.MauSacServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class MauSacService implements MauSacServiceIpm {
    @Autowired
    MausacEntityRepository MausacEntityRepository;

    @Override
    public List<MausacEntity> findAll() {
        return MausacEntityRepository.findAll();
    }

    @Override
    public List<MausacEntity> findAllById(Iterable<Integer> integers) {
        return MausacEntityRepository.findAllById(integers);
    }

    @Override
    public <S extends MausacEntity> S save(S entity) {
        return MausacEntityRepository.save(entity);
    }

    @Override
    public Optional<MausacEntity> findById(Integer integer) {
        return MausacEntityRepository.findById(integer);
    }

    @Override
    public void deleteById(Integer integer) {
        MausacEntityRepository.deleteById(integer);
    }
}
