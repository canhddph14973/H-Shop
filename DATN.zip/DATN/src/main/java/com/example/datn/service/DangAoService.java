package com.example.datn.service;

import com.example.datn.Entity.DangaoEntity;
import com.example.datn.Reponsitory.DangaoEntityRepository;
import com.example.datn.ServiceIpm.DangAoServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class DangAoService implements DangAoServiceIpm {
    @Autowired
  DangaoEntityRepository DangaoEntityRepository;

    @Override
    public List<DangaoEntity> findAll() {
        return DangaoEntityRepository.findAll();
    }

    @Override
    public List<DangaoEntity> findAllById(Iterable<Integer> integers) {
        return DangaoEntityRepository.findAllById(integers);
    }

    @Override
    public <S extends DangaoEntity> S save(S entity) {
        return DangaoEntityRepository.save(entity);
    }

    @Override
    public Optional<DangaoEntity> findById(Integer integer) {
        return DangaoEntityRepository.findById(integer);
    }

    @Override
    public void deleteById(Integer integer) {
        DangaoEntityRepository.deleteById(integer);
    }
}
