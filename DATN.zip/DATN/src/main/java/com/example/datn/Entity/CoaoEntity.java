package com.example.datn.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "coao", schema = "datn", catalog = "")
public class CoaoEntity {
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Id
    @Column(name = "Id")
    private int id;
    @Basic
    @Column(name = "TenCoAo")
    private String tenCoAo;
    @Basic
    @Column(name = "MoTa")
    private String moTa;
    @Basic
    @Column(name = "TrangThai")
    private int trangThai;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTenCoAo() {
        return tenCoAo;
    }

    public void setTenCoAo(String tenCoAo) {
        this.tenCoAo = tenCoAo;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CoaoEntity that = (CoaoEntity) o;

        if (id != that.id) return false;
        if (trangThai != that.trangThai) return false;
        if (tenCoAo != null ? !tenCoAo.equals(that.tenCoAo) : that.tenCoAo != null) return false;
        if (moTa != null ? !moTa.equals(that.moTa) : that.moTa != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (tenCoAo != null ? tenCoAo.hashCode() : 0);
        result = 31 * result + (moTa != null ? moTa.hashCode() : 0);
        result = 31 * result + trangThai;
        return result;
    }
}
