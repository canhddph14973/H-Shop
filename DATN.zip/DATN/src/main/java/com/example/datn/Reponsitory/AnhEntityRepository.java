package com.example.datn.Reponsitory;

import com.example.datn.Entity.AnhEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnhEntityRepository extends JpaRepository<AnhEntity, Integer> {

}