package com.example.datn.service;

import com.example.datn.Entity.CoaoEntity;
import com.example.datn.Reponsitory.CoaoEntityRepository;
import com.example.datn.ServiceIpm.CoAoServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class CoAoService implements CoAoServiceIpm {
    @Autowired
   CoaoEntityRepository CoaoEntityRepository;

    @Override
    public List<CoaoEntity> findAll() {
        return CoaoEntityRepository.findAll();
    }

    @Override
    public List<CoaoEntity> findAllById(Iterable<Integer> integers) {
        return CoaoEntityRepository.findAllById(integers);
    }

    @Override
    public <S extends CoaoEntity> S save(S entity) {
        return CoaoEntityRepository.save(entity);
    }

    @Override
    public Optional<CoaoEntity> findById(Integer integer) {
        return CoaoEntityRepository.findById(integer);
    }

    @Override
    public void deleteById(Integer integer) {
        CoaoEntityRepository.deleteById(integer);
    }
}
