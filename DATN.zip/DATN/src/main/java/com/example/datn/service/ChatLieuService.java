package com.example.datn.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import  com.example.datn.ServiceIpm.ChatLieuServiceIpm;
import java.util.List;
import java.util.Optional;
import com.example.datn.Entity.ChatlieuEntity;
import com.example.datn.Reponsitory.ChatlieuEntityRepository;
@Service
public class ChatLieuService implements ChatLieuServiceIpm{
    @Autowired
    ChatlieuEntityRepository ChatlieuEntityRepository;

    @Override
    public List<ChatlieuEntity> findAll() {
        return ChatlieuEntityRepository.findAll();
    }

    @Override
    public List<ChatlieuEntity> findAllById(Iterable<Integer> integers) {
        return ChatlieuEntityRepository.findAllById(integers);
    }

    @Override
    public <S extends ChatlieuEntity> S save(S entity) {
        return ChatlieuEntityRepository.save(entity);
    }

    @Override
    public Optional<ChatlieuEntity> findById(Integer integer) {
        return ChatlieuEntityRepository.findById(integer);
    }

    @Override
    public void deleteById(Integer integer) {
        ChatlieuEntityRepository.deleteById(integer);
    }
}
