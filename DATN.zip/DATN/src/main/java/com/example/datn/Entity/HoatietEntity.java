package com.example.datn.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "hoatiet", schema = "datn", catalog = "")
public class HoatietEntity {
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Id
    @Column(name = "Id")
    private int id;
    @Basic
    @Column(name = "TenHoaTiet")
    private String tenHoaTiet;
    @Basic
    @Column(name = "MoTa")
    private String moTa;
    @Basic
    @Column(name = "TrangThai")
    private int trangThai;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTenHoaTiet() {
        return tenHoaTiet;
    }

    public void setTenHoaTiet(String tenHoaTiet) {
        this.tenHoaTiet = tenHoaTiet;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }


}
