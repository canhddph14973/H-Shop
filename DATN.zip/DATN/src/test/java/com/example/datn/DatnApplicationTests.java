package com.example.datn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatnApplicationTests {

    @Test
    void contextLoads() {
    }

}
