package com.example.datn.service;

import com.example.datn.Entity.SanphamchitietEntity;
import com.example.datn.Reponsitory.SanphamchitietEntityRepository;
import com.example.datn.ServiceIpm.SanPhamChiTietServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class SanPhamChiTietService implements SanPhamChiTietServiceIpm {
    @Autowired
    SanphamchitietEntityRepository SanphamchitietEntityRepository;

    @Override
    public List<SanphamchitietEntity> findAll() {
        return SanphamchitietEntityRepository.findAll();
    }

    @Override
    public List<SanphamchitietEntity> findAllById(Iterable<Integer> integers) {
        return SanphamchitietEntityRepository.findAllById(integers);
    }

    @Override
    public <S extends SanphamchitietEntity> S save(S entity) {
        return SanphamchitietEntityRepository.save(entity);
    }

    @Override
    public Optional<SanphamchitietEntity> findById(Integer integer) {
        return SanphamchitietEntityRepository.findById(integer);
    }

    @Override
    public void deleteById(Integer integer) {
        SanphamchitietEntityRepository.deleteById(integer);
    }
}
