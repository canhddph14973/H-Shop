package com.example.datn.Entity;

import jakarta.persistence.*;

import java.sql.Timestamp;

@Entity
@Table(name = "hoadon", schema = "datn", catalog = "")
public class HoadonEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "Id")
    private int id;
    @Basic
    @Column(name = "IdKhachHang")
    private int idKhachHang;
    @Basic
    @Column(name = "IdHoaDonChiTiet")
    private int idHoaDonChiTiet;
    @Basic
    @Column(name = "NgayTao")
    private Timestamp ngayTao;
    @Basic
    @Column(name = "NgayCapNhat")
    private Timestamp ngayCapNhat;
    @Basic
    @Column(name = "NguoiTao")
    private String nguoiTao;
    @Basic
    @Column(name = "NguoiCapNhat")
    private String nguoiCapNhat;
    @Basic
    @Column(name = "TongTienHoaDon")
    private double tongTienHoaDon;
    @Basic
    @Column(name = "TienGiamGia")
    private double tienGiamGia;
    @Basic
    @Column(name = "ThanhTien")
    private double thanhTien;
    @Basic
    @Column(name = "HinhThucThanhToan")
    private String hinhThucThanhToan;
    @Basic
    @Column(name = "PhiVanChuyen")
    private double phiVanChuyen;
    @Basic
    @Column(name = "TrangThaiThanhToan")
    private int trangThaiThanhToan;
    @Basic
    @Column(name = "DiaChiGiaoHang")
    private String diaChiGiaoHang;
    @Basic
    @Column(name = "ThoiGianGiaoHang")
    private Timestamp thoiGianGiaoHang;
    @Basic
    @Column(name = "NguoiThanhToan")
    private String nguoiThanhToan;
    @Basic
    @Column(name = "TrangThai")
    private int trangThai;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdKhachHang() {
        return idKhachHang;
    }

    public void setIdKhachHang(int idKhachHang) {
        this.idKhachHang = idKhachHang;
    }

    public int getIdHoaDonChiTiet() {
        return idHoaDonChiTiet;
    }

    public void setIdHoaDonChiTiet(int idHoaDonChiTiet) {
        this.idHoaDonChiTiet = idHoaDonChiTiet;
    }

    public Timestamp getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Timestamp ngayTao) {
        this.ngayTao = ngayTao;
    }

    public Timestamp getNgayCapNhat() {
        return ngayCapNhat;
    }

    public void setNgayCapNhat(Timestamp ngayCapNhat) {
        this.ngayCapNhat = ngayCapNhat;
    }

    public String getNguoiTao() {
        return nguoiTao;
    }

    public void setNguoiTao(String nguoiTao) {
        this.nguoiTao = nguoiTao;
    }

    public String getNguoiCapNhat() {
        return nguoiCapNhat;
    }

    public void setNguoiCapNhat(String nguoiCapNhat) {
        this.nguoiCapNhat = nguoiCapNhat;
    }

    public double getTongTienHoaDon() {
        return tongTienHoaDon;
    }

    public void setTongTienHoaDon(double tongTienHoaDon) {
        this.tongTienHoaDon = tongTienHoaDon;
    }

    public double getTienGiamGia() {
        return tienGiamGia;
    }

    public void setTienGiamGia(double tienGiamGia) {
        this.tienGiamGia = tienGiamGia;
    }

    public double getThanhTien() {
        return thanhTien;
    }

    public void setThanhTien(double thanhTien) {
        this.thanhTien = thanhTien;
    }

    public String getHinhThucThanhToan() {
        return hinhThucThanhToan;
    }

    public void setHinhThucThanhToan(String hinhThucThanhToan) {
        this.hinhThucThanhToan = hinhThucThanhToan;
    }

    public double getPhiVanChuyen() {
        return phiVanChuyen;
    }

    public void setPhiVanChuyen(double phiVanChuyen) {
        this.phiVanChuyen = phiVanChuyen;
    }

    public int getTrangThaiThanhToan() {
        return trangThaiThanhToan;
    }

    public void setTrangThaiThanhToan(int trangThaiThanhToan) {
        this.trangThaiThanhToan = trangThaiThanhToan;
    }

    public String getDiaChiGiaoHang() {
        return diaChiGiaoHang;
    }

    public void setDiaChiGiaoHang(String diaChiGiaoHang) {
        this.diaChiGiaoHang = diaChiGiaoHang;
    }

    public Timestamp getThoiGianGiaoHang() {
        return thoiGianGiaoHang;
    }

    public void setThoiGianGiaoHang(Timestamp thoiGianGiaoHang) {
        this.thoiGianGiaoHang = thoiGianGiaoHang;
    }

    public String getNguoiThanhToan() {
        return nguoiThanhToan;
    }

    public void setNguoiThanhToan(String nguoiThanhToan) {
        this.nguoiThanhToan = nguoiThanhToan;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        HoadonEntity that = (HoadonEntity) o;

        if (id != that.id) return false;
        if (idKhachHang != that.idKhachHang) return false;
        if (idHoaDonChiTiet != that.idHoaDonChiTiet) return false;
        if (Double.compare(tongTienHoaDon, that.tongTienHoaDon) != 0) return false;
        if (Double.compare(tienGiamGia, that.tienGiamGia) != 0) return false;
        if (Double.compare(thanhTien, that.thanhTien) != 0) return false;
        if (Double.compare(phiVanChuyen, that.phiVanChuyen) != 0) return false;
        if (trangThaiThanhToan != that.trangThaiThanhToan) return false;
        if (trangThai != that.trangThai) return false;
        if (ngayTao != null ? !ngayTao.equals(that.ngayTao) : that.ngayTao != null) return false;
        if (ngayCapNhat != null ? !ngayCapNhat.equals(that.ngayCapNhat) : that.ngayCapNhat != null) return false;
        if (nguoiTao != null ? !nguoiTao.equals(that.nguoiTao) : that.nguoiTao != null) return false;
        if (nguoiCapNhat != null ? !nguoiCapNhat.equals(that.nguoiCapNhat) : that.nguoiCapNhat != null) return false;
        if (hinhThucThanhToan != null ? !hinhThucThanhToan.equals(that.hinhThucThanhToan) : that.hinhThucThanhToan != null)
            return false;
        if (diaChiGiaoHang != null ? !diaChiGiaoHang.equals(that.diaChiGiaoHang) : that.diaChiGiaoHang != null)
            return false;
        if (thoiGianGiaoHang != null ? !thoiGianGiaoHang.equals(that.thoiGianGiaoHang) : that.thoiGianGiaoHang != null)
            return false;
        if (nguoiThanhToan != null ? !nguoiThanhToan.equals(that.nguoiThanhToan) : that.nguoiThanhToan != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = id;
        result = 31 * result + idKhachHang;
        result = 31 * result + idHoaDonChiTiet;
        result = 31 * result + (ngayTao != null ? ngayTao.hashCode() : 0);
        result = 31 * result + (ngayCapNhat != null ? ngayCapNhat.hashCode() : 0);
        result = 31 * result + (nguoiTao != null ? nguoiTao.hashCode() : 0);
        result = 31 * result + (nguoiCapNhat != null ? nguoiCapNhat.hashCode() : 0);
        temp = Double.doubleToLongBits(tongTienHoaDon);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(tienGiamGia);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(thanhTien);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + (hinhThucThanhToan != null ? hinhThucThanhToan.hashCode() : 0);
        temp = Double.doubleToLongBits(phiVanChuyen);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + trangThaiThanhToan;
        result = 31 * result + (diaChiGiaoHang != null ? diaChiGiaoHang.hashCode() : 0);
        result = 31 * result + (thoiGianGiaoHang != null ? thoiGianGiaoHang.hashCode() : 0);
        result = 31 * result + (nguoiThanhToan != null ? nguoiThanhToan.hashCode() : 0);
        result = 31 * result + trangThai;
        return result;
    }
}
