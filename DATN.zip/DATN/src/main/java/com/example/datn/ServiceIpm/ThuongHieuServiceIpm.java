package com.example.datn.ServiceIpm;

import com.example.datn.Entity.ThuonghieuEntity;

import java.util.List;
import java.util.Optional;

public interface ThuongHieuServiceIpm {
    List<ThuonghieuEntity> findAll();

    List<ThuonghieuEntity> findAllById(Iterable<Integer> integers);

    <S extends ThuonghieuEntity> S save(S entity);

    Optional<ThuonghieuEntity> findById(Integer integer);

    void deleteById(Integer integer);
}
