package com.example.datn.Controller;


import com.example.datn.Entity.HoatietEntity;
import com.example.datn.ServiceIpm.HoaTietServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@Controller
@RequestMapping("/HoaTiet")
public class HoatTietController {
    @Autowired
    HoaTietServiceIpm HoaTietServiceIpm;


    @GetMapping("/list")
    public String list(Model model){
        List<HoatietEntity> hoatiet=  HoaTietServiceIpm.findAll();
        model.addAttribute("hoatiet",hoatiet);

        return "HoaTiet/list";
    }
    @GetMapping("/create")
    public String create(Model model){
        HoatietEntity hoatiet =new HoatietEntity();
        model.addAttribute("hoatiet",hoatiet);
        return "HoaTiet/add";
    }

    @PostMapping("/add")
    public String Add(@ModelAttribute("hoatiet") HoatietEntity hoatiet){
        HoaTietServiceIpm.save(hoatiet);
        return "redirect:/HoaTiet/list";
    }
    @GetMapping("/getId")
    public String getId(Model model,@RequestParam("id") int id  ) {
        Optional<HoatietEntity> hoatiet = HoaTietServiceIpm.findById(id);
        if (hoatiet.isPresent()) {
            model.addAttribute("hoatiet", hoatiet.get());
        } else {
            model.addAttribute("hoatiet", new HoatietEntity());
        }
        return "HoaTiet/update";
    }


    @PostMapping("/update")
    public String update(@ModelAttribute("hoatiet") HoatietEntity hoatiet){
        HoaTietServiceIpm.save(hoatiet);
        return "redirect:/HoaTiet/list";
    }
    @GetMapping("/delete")
    public String deleteId(@RequestParam("id") int id){

        HoaTietServiceIpm.deleteById(id);
        return "redirect:/HoaTiet/list";
    }
}
