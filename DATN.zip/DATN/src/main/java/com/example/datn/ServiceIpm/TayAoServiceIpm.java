package com.example.datn.ServiceIpm;

import com.example.datn.Entity.TayaoEntity;

import java.util.List;
import java.util.Optional;

public interface TayAoServiceIpm {
    List<TayaoEntity> findAll();

    List<TayaoEntity> findAllById(Iterable<Integer> integers);

    <S extends TayaoEntity> S save(S entity);

    Optional<TayaoEntity> findById(Integer integer);

    void deleteById(Integer integer);
}
