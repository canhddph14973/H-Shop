package com.example.datn.ServiceIpm;

import com.example.datn.Entity.CoaoEntity;

import java.util.List;
import java.util.Optional;

public interface CoAoServiceIpm {
    List<CoaoEntity> findAll();

    List<CoaoEntity> findAllById(Iterable<Integer> integers);

    <S extends CoaoEntity> S save(S entity);

    Optional<CoaoEntity> findById(Integer integer);

    void deleteById(Integer integer);
}
