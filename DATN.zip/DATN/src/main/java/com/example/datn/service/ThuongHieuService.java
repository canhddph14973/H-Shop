package com.example.datn.service;

import com.example.datn.Entity.ThuonghieuEntity;
import com.example.datn.Reponsitory.ThuonghieuEntityRepository;
import com.example.datn.ServiceIpm.ThuongHieuServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class ThuongHieuService implements ThuongHieuServiceIpm {
    @Autowired
    ThuonghieuEntityRepository ThuonghieuEntityRepository;

    @Override
    public List<ThuonghieuEntity> findAll() {
        return ThuonghieuEntityRepository.findAll();
    }

    @Override
    public List<ThuonghieuEntity> findAllById(Iterable<Integer> integers) {
        return ThuonghieuEntityRepository.findAllById(integers);
    }

    @Override
    public <S extends ThuonghieuEntity> S save(S entity) {
        return ThuonghieuEntityRepository.save(entity);
    }

    @Override
    public Optional<ThuonghieuEntity> findById(Integer integer) {
        return ThuonghieuEntityRepository.findById(integer);
    }

    @Override
    public void deleteById(Integer integer) {
        ThuonghieuEntityRepository.deleteById(integer);
    }
}
