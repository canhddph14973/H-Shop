package com.example.datn.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "dangao", schema = "datn", catalog = "")
public class DangaoEntity {
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Id
    @Column(name = "Id")
    private int id;
    @Basic
    @Column(name = "TenDangAo")
    private String tenDangAo;
    @Basic
    @Column(name = "MoTa")
    private String moTa;
    @Basic
    @Column(name = "TrangThai")
    private int trangThai;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTenDangAo() {
        return tenDangAo;
    }

    public void setTenDangAo(String tenDangAo) {
        this.tenDangAo = tenDangAo;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DangaoEntity that = (DangaoEntity) o;

        if (id != that.id) return false;
        if (trangThai != that.trangThai) return false;
        if (tenDangAo != null ? !tenDangAo.equals(that.tenDangAo) : that.tenDangAo != null) return false;
        if (moTa != null ? !moTa.equals(that.moTa) : that.moTa != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (tenDangAo != null ? tenDangAo.hashCode() : 0);
        result = 31 * result + (moTa != null ? moTa.hashCode() : 0);
        result = 31 * result + trangThai;
        return result;
    }
}
