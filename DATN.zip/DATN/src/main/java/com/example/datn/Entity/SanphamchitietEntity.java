package com.example.datn.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "sanphamchitiet", schema = "datn", catalog = "")
public class SanphamchitietEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "Id")
    private int id;
    @Basic
    @Column(name = "IdSp")
    private int idSp;
    @Basic
    @Column(name = "IdAnh")
    private int idAnh;
    @Basic
    @Column(name = "IdMauSac")
    private int idMauSac;
    @Basic
    @Column(name = "IdChatLieu")
    private int idChatLieu;
    @Basic
    @Column(name = "IdThuongHieu")
    private int idThuongHieu;
    @Basic
    @Column(name = "IdKichCo")
    private int idKichCo;
    @Basic
    @Column(name = "IdDangAo")
    private int idDangAo;
    @Basic
    @Column(name = "IdCoAo")
    private int idCoAo;
    @Basic
    @Column(name = "IdTayAo")
    private int idTayAo;
    @Basic
    @Column(name = "IdHoaTiet")
    private int idHoaTiet;
    @Basic
    @Column(name = "GiaNhap")
    private double giaNhap;
    @Basic
    @Column(name = "GiaBan")
    private double giaBan;
    @Basic
    @Column(name = "MoTa")
    private String moTa;
    @Basic
    @Column(name = "SoLuong")
    private int soLuong;
    @Basic
    @Column(name = "TrangThai")
    private int trangThai;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdSp() {
        return idSp;
    }

    public void setIdSp(int idSp) {
        this.idSp = idSp;
    }

    public int getIdAnh() {
        return idAnh;
    }

    public void setIdAnh(int idAnh) {
        this.idAnh = idAnh;
    }

    public int getIdMauSac() {
        return idMauSac;
    }

    public void setIdMauSac(int idMauSac) {
        this.idMauSac = idMauSac;
    }

    public int getIdChatLieu() {
        return idChatLieu;
    }

    public void setIdChatLieu(int idChatLieu) {
        this.idChatLieu = idChatLieu;
    }

    public int getIdThuongHieu() {
        return idThuongHieu;
    }

    public void setIdThuongHieu(int idThuongHieu) {
        this.idThuongHieu = idThuongHieu;
    }

    public int getIdKichCo() {
        return idKichCo;
    }

    public void setIdKichCo(int idKichCo) {
        this.idKichCo = idKichCo;
    }

    public int getIdDangAo() {
        return idDangAo;
    }

    public void setIdDangAo(int idDangAo) {
        this.idDangAo = idDangAo;
    }

    public int getIdCoAo() {
        return idCoAo;
    }

    public void setIdCoAo(int idCoAo) {
        this.idCoAo = idCoAo;
    }

    public int getIdTayAo() {
        return idTayAo;
    }

    public void setIdTayAo(int idTayAo) {
        this.idTayAo = idTayAo;
    }

    public int getIdHoaTiet() {
        return idHoaTiet;
    }

    public void setIdHoaTiet(int idHoaTiet) {
        this.idHoaTiet = idHoaTiet;
    }

    public double getGiaNhap() {
        return giaNhap;
    }

    public void setGiaNhap(double giaNhap) {
        this.giaNhap = giaNhap;
    }

    public double getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(double giaBan) {
        this.giaBan = giaBan;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SanphamchitietEntity that = (SanphamchitietEntity) o;

        if (id != that.id) return false;
        if (idSp != that.idSp) return false;
        if (idAnh != that.idAnh) return false;
        if (idMauSac != that.idMauSac) return false;
        if (idChatLieu != that.idChatLieu) return false;
        if (idThuongHieu != that.idThuongHieu) return false;
        if (idKichCo != that.idKichCo) return false;
        if (idDangAo != that.idDangAo) return false;
        if (idCoAo != that.idCoAo) return false;
        if (idTayAo != that.idTayAo) return false;
        if (idHoaTiet != that.idHoaTiet) return false;
        if (Double.compare(giaNhap, that.giaNhap) != 0) return false;
        if (Double.compare(giaBan, that.giaBan) != 0) return false;
        if (soLuong != that.soLuong) return false;
        if (trangThai != that.trangThai) return false;
        if (moTa != null ? !moTa.equals(that.moTa) : that.moTa != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = id;
        result = 31 * result + idSp;
        result = 31 * result + idAnh;
        result = 31 * result + idMauSac;
        result = 31 * result + idChatLieu;
        result = 31 * result + idThuongHieu;
        result = 31 * result + idKichCo;
        result = 31 * result + idDangAo;
        result = 31 * result + idCoAo;
        result = 31 * result + idTayAo;
        result = 31 * result + idHoaTiet;
        temp = Double.doubleToLongBits(giaNhap);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(giaBan);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + (moTa != null ? moTa.hashCode() : 0);
        result = 31 * result + soLuong;
        result = 31 * result + trangThai;
        return result;
    }
}
