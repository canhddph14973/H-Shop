package com.example.datn.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "diachi", schema = "datn", catalog = "")
public class DiachiEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "Id")
    private int id;
    @Basic
    @Column(name = "IdKhachHang")
    private int idKhachHang;
    @Basic
    @Column(name = "Diachi")
    private String diachi;
    @Basic
    @Column(name = "GhiChu")
    private String ghiChu;
    @Basic
    @Column(name = "TrangThai")
    private int trangThai;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdKhachHang() {
        return idKhachHang;
    }

    public void setIdKhachHang(int idKhachHang) {
        this.idKhachHang = idKhachHang;
    }

    public String getDiachi() {
        return diachi;
    }

    public void setDiachi(String diachi) {
        this.diachi = diachi;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DiachiEntity that = (DiachiEntity) o;

        if (id != that.id) return false;
        if (idKhachHang != that.idKhachHang) return false;
        if (trangThai != that.trangThai) return false;
        if (diachi != null ? !diachi.equals(that.diachi) : that.diachi != null) return false;
        if (ghiChu != null ? !ghiChu.equals(that.ghiChu) : that.ghiChu != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + idKhachHang;
        result = 31 * result + (diachi != null ? diachi.hashCode() : 0);
        result = 31 * result + (ghiChu != null ? ghiChu.hashCode() : 0);
        result = 31 * result + trangThai;
        return result;
    }
}
