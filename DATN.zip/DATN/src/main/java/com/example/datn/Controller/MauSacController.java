package com.example.datn.Controller;

import com.example.datn.Entity.MausacEntity;
import com.example.datn.ServiceIpm.MauSacServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@RestController
@RequestMapping("/MauSac")
public class MauSacController {
    @Autowired
    MauSacServiceIpm MauSacServiceIpm;

    @GetMapping("")
    public List<MausacEntity> list(){
        return MauSacServiceIpm.findAll();
    }

    @PostMapping("")
    public MausacEntity Add(@RequestBody MausacEntity MausacEntity){
        return MauSacServiceIpm.save(MausacEntity);
    }
    @GetMapping("/{id}")
    public Optional<MausacEntity> getId(@PathVariable("id") int id ){
        return MauSacServiceIpm.findById(id);
    }
    @PutMapping("/{id}")
    public MausacEntity update(@PathVariable("id") int id,@RequestBody MausacEntity MausacEntity){
        return MauSacServiceIpm.save(MausacEntity);
    }
    @DeleteMapping("/deleteAnh/{id}")
    public void delete(@PathVariable("id") int id){
        MauSacServiceIpm.deleteById(id);
    }
}
