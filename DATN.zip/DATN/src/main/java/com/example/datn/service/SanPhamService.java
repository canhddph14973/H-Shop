package com.example.datn.service;

import com.example.datn.Entity.SanphamEntity;
import com.example.datn.Reponsitory.SanphamEntityRepository;
import com.example.datn.ServiceIpm.SanhamServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class SanPhamService implements SanhamServiceIpm {
    @Autowired
    SanphamEntityRepository SanphamEntityRepository;

    @Override
    public List<SanphamEntity> findAll() {
        return SanphamEntityRepository.findAll();
    }

    @Override
    public List<SanphamEntity> findAllById(Iterable<Integer> integers) {
        return SanphamEntityRepository.findAllById(integers);
    }

    @Override
    public <S extends SanphamEntity> S save(S entity) {
        return SanphamEntityRepository.save(entity);
    }

    @Override
    public Optional<SanphamEntity> findById(Integer integer) {
        return SanphamEntityRepository.findById(integer);
    }

    @Override
    public void deleteById(Integer integer) {
        SanphamEntityRepository.deleteById(integer);    }
}
