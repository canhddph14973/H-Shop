package com.example.datn.ServiceIpm;

import com.example.datn.Entity.AnhEntity;

import java.util.List;
import java.util.Optional;

public interface AnhServiceIpm {
    List<AnhEntity> findAll();

    List<AnhEntity> findAllById(Iterable<Integer> integers);

    <S extends AnhEntity> S save(S entity);

    Optional<AnhEntity> findById(Integer integer);

    void deleteById(Integer integer);
}
