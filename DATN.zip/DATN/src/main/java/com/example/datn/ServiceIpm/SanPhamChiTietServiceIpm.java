package com.example.datn.ServiceIpm;

import com.example.datn.Entity.SanphamchitietEntity;

import java.util.List;
import java.util.Optional;

public interface SanPhamChiTietServiceIpm {
    List<SanphamchitietEntity> findAll();

    List<SanphamchitietEntity> findAllById(Iterable<Integer> integers);

    <S extends SanphamchitietEntity> S save(S entity);

    Optional<SanphamchitietEntity> findById(Integer integer);

    void deleteById(Integer integer);
}
