package com.example.datn.service;

import com.example.datn.Entity.HoatietEntity;
import com.example.datn.Reponsitory.HoatietEntityRepository;
import com.example.datn.ServiceIpm.HoaTietServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class HoaTietService implements HoaTietServiceIpm {
    @Autowired
    HoatietEntityRepository HoatietEntityRepository;

    @Override
    public List<HoatietEntity> findAll() {
        return HoatietEntityRepository.findAll();
    }

    @Override
    public List<HoatietEntity> findAllById(Iterable<Integer> integers) {
        return HoatietEntityRepository.findAllById(integers);
    }

    @Override
    public <S extends HoatietEntity> S save(S entity) {
        return HoatietEntityRepository.save(entity);
    }

    @Override
    public Optional<HoatietEntity> findById(Integer integer) {
        return HoatietEntityRepository.findById(integer);
    }

    @Override
    public void deleteById(Integer integer) {
        HoatietEntityRepository.deleteById(integer);
    }
}
