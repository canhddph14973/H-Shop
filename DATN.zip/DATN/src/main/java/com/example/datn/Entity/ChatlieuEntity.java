package com.example.datn.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "chatlieu", schema = "datn", catalog = "")
public class ChatlieuEntity {
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Id
    @Column(name = "Id")
    private int id;
    @Basic
    @Column(name = "mo_ta")
    private String moTa;
    @Basic
    @Column(name = "ten_chat_lieu")
    private String tenChatLieu;
    @Basic
    @Column(name = "trang_thai")
    private Integer trangThai;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public String getTenChatLieu() {
        return tenChatLieu;
    }

    public void setTenChatLieu(String tenChatLieu) {
        this.tenChatLieu = tenChatLieu;
    }

    public Integer getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(Integer trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ChatlieuEntity that = (ChatlieuEntity) o;

        if (id != that.id) return false;
        if (moTa != null ? !moTa.equals(that.moTa) : that.moTa != null) return false;
        if (tenChatLieu != null ? !tenChatLieu.equals(that.tenChatLieu) : that.tenChatLieu != null) return false;
        if (trangThai != null ? !trangThai.equals(that.trangThai) : that.trangThai != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (moTa != null ? moTa.hashCode() : 0);
        result = 31 * result + (tenChatLieu != null ? tenChatLieu.hashCode() : 0);
        result = 31 * result + (trangThai != null ? trangThai.hashCode() : 0);
        return result;
    }
}
