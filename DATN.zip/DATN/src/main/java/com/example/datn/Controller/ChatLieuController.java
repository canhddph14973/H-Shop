package com.example.datn.Controller;

import com.example.datn.ServiceIpm.ChatLieuServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.example.datn.Entity.ChatlieuEntity;
import java.util.List;
import java.util.Optional;
@Controller
@RequestMapping("/ChatLieu")
public class ChatLieuController {
    @Autowired
    ChatLieuServiceIpm chatLieuServiceIpm;

    @GetMapping("/listChatLieu")
    public String list(Model model){
            List<ChatlieuEntity> chatlieu=  chatLieuServiceIpm.findAll();
            model.addAttribute("chatlieu",chatlieu);

        return "ChatLieu/listChatLieu";
    }
    @GetMapping("/createChatLieu")
    public String create(Model model){
        ChatlieuEntity chatlieu =new ChatlieuEntity();
        model.addAttribute("chatlieu",chatlieu);
        return "ChatLieu/addChatLieu";
    }

    @PostMapping("/addChatLieu")
    public String Add(@ModelAttribute("chatlieu") ChatlieuEntity chatlieu){
       chatLieuServiceIpm.save(chatlieu);
        return "redirect:/ChatLieu/listChatLieu";
    }
    @GetMapping("/getId")
    public String getId(Model model,@RequestParam("id") int id  ) {
        Optional<ChatlieuEntity> chatlieu = chatLieuServiceIpm.findById(id);
        if (chatlieu.isPresent()) {
            model.addAttribute("chatlieu", chatlieu.get());
        } else {
            model.addAttribute("chatlieu", new ChatlieuEntity());
        }
        return "ChatLieu/updateChatLieu";
    }


    @PostMapping("/updateChatLieu")
    public String update(@ModelAttribute("chatlieu") ChatlieuEntity chatlieu){
        chatLieuServiceIpm.save(chatlieu);
        return "redirect:/ChatLieu/listChatLieu";
    }
    @GetMapping("/delete")
    public String deleteId(@RequestParam("id") int id){

        chatLieuServiceIpm.deleteById(id);
        return "redirect:/ChatLieu/listChatLieu";
    }
}
