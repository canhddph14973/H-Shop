package com.example.datn.Entity;

import jakarta.persistence.*;

import java.sql.Timestamp;

@Entity
@Table(name = "lichsuhoadon", schema = "datn", catalog = "")
public class LichsuhoadonEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "Id")
    private int id;
    @Basic
    @Column(name = "IdHoaDon")
    private int idHoaDon;
    @Basic
    @Column(name = "NgayTao")
    private Timestamp ngayTao;
    @Basic
    @Column(name = "NgayCapNhat")
    private Timestamp ngayCapNhat;
    @Basic
    @Column(name = "NguoiTao")
    private Timestamp nguoiTao;
    @Basic
    @Column(name = "NguoiCapNhat")
    private int nguoiCapNhat;
    @Basic
    @Column(name = "NhungThayDoi")
    private String nhungThayDoi;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdHoaDon() {
        return idHoaDon;
    }

    public void setIdHoaDon(int idHoaDon) {
        this.idHoaDon = idHoaDon;
    }

    public Timestamp getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Timestamp ngayTao) {
        this.ngayTao = ngayTao;
    }

    public Timestamp getNgayCapNhat() {
        return ngayCapNhat;
    }

    public void setNgayCapNhat(Timestamp ngayCapNhat) {
        this.ngayCapNhat = ngayCapNhat;
    }

    public Timestamp getNguoiTao() {
        return nguoiTao;
    }

    public void setNguoiTao(Timestamp nguoiTao) {
        this.nguoiTao = nguoiTao;
    }

    public int getNguoiCapNhat() {
        return nguoiCapNhat;
    }

    public void setNguoiCapNhat(int nguoiCapNhat) {
        this.nguoiCapNhat = nguoiCapNhat;
    }

    public String getNhungThayDoi() {
        return nhungThayDoi;
    }

    public void setNhungThayDoi(String nhungThayDoi) {
        this.nhungThayDoi = nhungThayDoi;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LichsuhoadonEntity that = (LichsuhoadonEntity) o;

        if (id != that.id) return false;
        if (idHoaDon != that.idHoaDon) return false;
        if (nguoiCapNhat != that.nguoiCapNhat) return false;
        if (ngayTao != null ? !ngayTao.equals(that.ngayTao) : that.ngayTao != null) return false;
        if (ngayCapNhat != null ? !ngayCapNhat.equals(that.ngayCapNhat) : that.ngayCapNhat != null) return false;
        if (nguoiTao != null ? !nguoiTao.equals(that.nguoiTao) : that.nguoiTao != null) return false;
        if (nhungThayDoi != null ? !nhungThayDoi.equals(that.nhungThayDoi) : that.nhungThayDoi != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + idHoaDon;
        result = 31 * result + (ngayTao != null ? ngayTao.hashCode() : 0);
        result = 31 * result + (ngayCapNhat != null ? ngayCapNhat.hashCode() : 0);
        result = 31 * result + (nguoiTao != null ? nguoiTao.hashCode() : 0);
        result = 31 * result + nguoiCapNhat;
        result = 31 * result + (nhungThayDoi != null ? nhungThayDoi.hashCode() : 0);
        return result;
    }
}
