package com.example.datn.Reponsitory;

import com.example.datn.Entity.SanphamchitietEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SanphamchitietEntityRepository extends JpaRepository<SanphamchitietEntity, Integer> {
}