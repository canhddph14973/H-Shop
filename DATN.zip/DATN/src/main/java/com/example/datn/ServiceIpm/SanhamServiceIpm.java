package com.example.datn.ServiceIpm;

import com.example.datn.Entity.SanphamEntity;

import java.util.List;
import java.util.Optional;

public interface SanhamServiceIpm {
    List<SanphamEntity> findAll();

    List<SanphamEntity> findAllById(Iterable<Integer> integers);

    <S extends SanphamEntity> S save(S entity);

    Optional<SanphamEntity> findById(Integer integer);

    void deleteById(Integer integer);
}
