package com.example.datn.Reponsitory;

import com.example.datn.Entity.ThuonghieuEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ThuonghieuEntityRepository extends JpaRepository<ThuonghieuEntity, Integer> {
}