package com.example.datn.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "thongke", schema = "datn", catalog = "")
public class ThongkeEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "Id")
    private int id;
    @Basic
    @Column(name = "IdHoaDon")
    private int idHoaDon;
    @Basic
    @Column(name = "IdSanPhamChiTiet")
    private int idSanPhamChiTiet;
    @Basic
    @Column(name = "DoanhThuThang")
    private double doanhThuThang;
    @Basic
    @Column(name = "DoanhThuNam")
    private double doanhThuNam;
    @Basic
    @Column(name = "KhachHangTiemNang")
    private String khachHangTiemNang;
    @Basic
    @Column(name = "SanPhamBanChay")
    private String sanPhamBanChay;
    @Basic
    @Column(name = "TrangThai")
    private int trangThai;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdHoaDon() {
        return idHoaDon;
    }

    public void setIdHoaDon(int idHoaDon) {
        this.idHoaDon = idHoaDon;
    }

    public int getIdSanPhamChiTiet() {
        return idSanPhamChiTiet;
    }

    public void setIdSanPhamChiTiet(int idSanPhamChiTiet) {
        this.idSanPhamChiTiet = idSanPhamChiTiet;
    }

    public double getDoanhThuThang() {
        return doanhThuThang;
    }

    public void setDoanhThuThang(double doanhThuThang) {
        this.doanhThuThang = doanhThuThang;
    }

    public double getDoanhThuNam() {
        return doanhThuNam;
    }

    public void setDoanhThuNam(double doanhThuNam) {
        this.doanhThuNam = doanhThuNam;
    }

    public String getKhachHangTiemNang() {
        return khachHangTiemNang;
    }

    public void setKhachHangTiemNang(String khachHangTiemNang) {
        this.khachHangTiemNang = khachHangTiemNang;
    }

    public String getSanPhamBanChay() {
        return sanPhamBanChay;
    }

    public void setSanPhamBanChay(String sanPhamBanChay) {
        this.sanPhamBanChay = sanPhamBanChay;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ThongkeEntity that = (ThongkeEntity) o;

        if (id != that.id) return false;
        if (idHoaDon != that.idHoaDon) return false;
        if (idSanPhamChiTiet != that.idSanPhamChiTiet) return false;
        if (Double.compare(doanhThuThang, that.doanhThuThang) != 0) return false;
        if (Double.compare(doanhThuNam, that.doanhThuNam) != 0) return false;
        if (trangThai != that.trangThai) return false;
        if (khachHangTiemNang != null ? !khachHangTiemNang.equals(that.khachHangTiemNang) : that.khachHangTiemNang != null)
            return false;
        if (sanPhamBanChay != null ? !sanPhamBanChay.equals(that.sanPhamBanChay) : that.sanPhamBanChay != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = id;
        result = 31 * result + idHoaDon;
        result = 31 * result + idSanPhamChiTiet;
        temp = Double.doubleToLongBits(doanhThuThang);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(doanhThuNam);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + (khachHangTiemNang != null ? khachHangTiemNang.hashCode() : 0);
        result = 31 * result + (sanPhamBanChay != null ? sanPhamBanChay.hashCode() : 0);
        result = 31 * result + trangThai;
        return result;
    }
}
