package com.example.datn.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "kichco", schema = "datn", catalog = "")
public class KichcoEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "Id")
    private int id;
    @Basic
    @Column(name = "TenKichCo")
    private String tenKichCo;
    @Basic
    @Column(name = "MoTa")
    private String moTa;
    @Basic
    @Column(name = "TrangThai")
    private int trangThai;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTenKichCo() {
        return tenKichCo;
    }

    public void setTenKichCo(String tenKichCo) {
        this.tenKichCo = tenKichCo;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        KichcoEntity that = (KichcoEntity) o;

        if (id != that.id) return false;
        if (trangThai != that.trangThai) return false;
        if (tenKichCo != null ? !tenKichCo.equals(that.tenKichCo) : that.tenKichCo != null) return false;
        if (moTa != null ? !moTa.equals(that.moTa) : that.moTa != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (tenKichCo != null ? tenKichCo.hashCode() : 0);
        result = 31 * result + (moTa != null ? moTa.hashCode() : 0);
        result = 31 * result + trangThai;
        return result;
    }
}
