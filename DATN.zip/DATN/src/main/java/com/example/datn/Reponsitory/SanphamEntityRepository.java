package com.example.datn.Reponsitory;

import com.example.datn.Entity.SanphamEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SanphamEntityRepository extends JpaRepository<SanphamEntity, Integer> {
}