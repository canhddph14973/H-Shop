package com.example.datn.Entity;

import jakarta.persistence.*;

import java.sql.Timestamp;

@Entity
@Table(name = "giamgia", schema = "datn", catalog = "")
public class GiamgiaEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "Id")
    private int id;
    @Basic
    @Column(name = "TenGiamGia")
    private String tenGiamGia;
    @Basic
    @Column(name = "LoaiGiamGia")
    private int loaiGiamGia;
    @Basic
    @Column(name = "GiaTriGiamGia")
    private int giaTriGiamGia;
    @Basic
    @Column(name = "SoLuong")
    private int soLuong;
    @Basic
    @Column(name = "NgayBatDau")
    private Timestamp ngayBatDau;
    @Basic
    @Column(name = "NgayKetThuc")
    private Timestamp ngayKetThuc;
    @Basic
    @Column(name = "NgayTao")
    private Timestamp ngayTao;
    @Basic
    @Column(name = "NgayCapNhat")
    private Timestamp ngayCapNhat;
    @Basic
    @Column(name = "NguoiTao")
    private String nguoiTao;
    @Basic
    @Column(name = "NguoiCapNhat")
    private String nguoiCapNhat;
    @Basic
    @Column(name = "TrangThai")
    private int trangThai;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTenGiamGia() {
        return tenGiamGia;
    }

    public void setTenGiamGia(String tenGiamGia) {
        this.tenGiamGia = tenGiamGia;
    }

    public int getLoaiGiamGia() {
        return loaiGiamGia;
    }

    public void setLoaiGiamGia(int loaiGiamGia) {
        this.loaiGiamGia = loaiGiamGia;
    }

    public int getGiaTriGiamGia() {
        return giaTriGiamGia;
    }

    public void setGiaTriGiamGia(int giaTriGiamGia) {
        this.giaTriGiamGia = giaTriGiamGia;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public Timestamp getNgayBatDau() {
        return ngayBatDau;
    }

    public void setNgayBatDau(Timestamp ngayBatDau) {
        this.ngayBatDau = ngayBatDau;
    }

    public Timestamp getNgayKetThuc() {
        return ngayKetThuc;
    }

    public void setNgayKetThuc(Timestamp ngayKetThuc) {
        this.ngayKetThuc = ngayKetThuc;
    }

    public Timestamp getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Timestamp ngayTao) {
        this.ngayTao = ngayTao;
    }

    public Timestamp getNgayCapNhat() {
        return ngayCapNhat;
    }

    public void setNgayCapNhat(Timestamp ngayCapNhat) {
        this.ngayCapNhat = ngayCapNhat;
    }

    public String getNguoiTao() {
        return nguoiTao;
    }

    public void setNguoiTao(String nguoiTao) {
        this.nguoiTao = nguoiTao;
    }

    public String getNguoiCapNhat() {
        return nguoiCapNhat;
    }

    public void setNguoiCapNhat(String nguoiCapNhat) {
        this.nguoiCapNhat = nguoiCapNhat;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        GiamgiaEntity that = (GiamgiaEntity) o;

        if (id != that.id) return false;
        if (loaiGiamGia != that.loaiGiamGia) return false;
        if (giaTriGiamGia != that.giaTriGiamGia) return false;
        if (soLuong != that.soLuong) return false;
        if (trangThai != that.trangThai) return false;
        if (tenGiamGia != null ? !tenGiamGia.equals(that.tenGiamGia) : that.tenGiamGia != null) return false;
        if (ngayBatDau != null ? !ngayBatDau.equals(that.ngayBatDau) : that.ngayBatDau != null) return false;
        if (ngayKetThuc != null ? !ngayKetThuc.equals(that.ngayKetThuc) : that.ngayKetThuc != null) return false;
        if (ngayTao != null ? !ngayTao.equals(that.ngayTao) : that.ngayTao != null) return false;
        if (ngayCapNhat != null ? !ngayCapNhat.equals(that.ngayCapNhat) : that.ngayCapNhat != null) return false;
        if (nguoiTao != null ? !nguoiTao.equals(that.nguoiTao) : that.nguoiTao != null) return false;
        if (nguoiCapNhat != null ? !nguoiCapNhat.equals(that.nguoiCapNhat) : that.nguoiCapNhat != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (tenGiamGia != null ? tenGiamGia.hashCode() : 0);
        result = 31 * result + loaiGiamGia;
        result = 31 * result + giaTriGiamGia;
        result = 31 * result + soLuong;
        result = 31 * result + (ngayBatDau != null ? ngayBatDau.hashCode() : 0);
        result = 31 * result + (ngayKetThuc != null ? ngayKetThuc.hashCode() : 0);
        result = 31 * result + (ngayTao != null ? ngayTao.hashCode() : 0);
        result = 31 * result + (ngayCapNhat != null ? ngayCapNhat.hashCode() : 0);
        result = 31 * result + (nguoiTao != null ? nguoiTao.hashCode() : 0);
        result = 31 * result + (nguoiCapNhat != null ? nguoiCapNhat.hashCode() : 0);
        result = 31 * result + trangThai;
        return result;
    }
}
