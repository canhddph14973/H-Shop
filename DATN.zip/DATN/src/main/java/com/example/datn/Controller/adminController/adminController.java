package com.example.datn.Controller.adminController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller

public class adminController {
    @RequestMapping("/admin")
    public String admin(){
        return "Admin/admin";
    }
    @RequestMapping("/DangAo/list")
    public String ChatLieu(){
        return "Admin/admin";
    }
}
