package com.example.datn.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "hoadonchitiet", schema = "datn", catalog = "")
public class HoadonchitietEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "Id")
    private int id;
    @Basic
    @Column(name = "IdSanPhamChiTiet")
    private int idSanPhamChiTiet;
    @Basic
    @Column(name = "SoLuong")
    private int soLuong;
    @Basic
    @Column(name = "DonGia")
    private double donGia;
    @Basic
    @Column(name = "ThanhTien")
    private double thanhTien;
    @Basic
    @Column(name = "TrangThai")
    private int trangThai;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdSanPhamChiTiet() {
        return idSanPhamChiTiet;
    }

    public void setIdSanPhamChiTiet(int idSanPhamChiTiet) {
        this.idSanPhamChiTiet = idSanPhamChiTiet;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public double getDonGia() {
        return donGia;
    }

    public void setDonGia(double donGia) {
        this.donGia = donGia;
    }

    public double getThanhTien() {
        return thanhTien;
    }

    public void setThanhTien(double thanhTien) {
        this.thanhTien = thanhTien;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        HoadonchitietEntity that = (HoadonchitietEntity) o;

        if (id != that.id) return false;
        if (idSanPhamChiTiet != that.idSanPhamChiTiet) return false;
        if (soLuong != that.soLuong) return false;
        if (Double.compare(donGia, that.donGia) != 0) return false;
        if (Double.compare(thanhTien, that.thanhTien) != 0) return false;
        if (trangThai != that.trangThai) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = id;
        result = 31 * result + idSanPhamChiTiet;
        result = 31 * result + soLuong;
        temp = Double.doubleToLongBits(donGia);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(thanhTien);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + trangThai;
        return result;
    }
}
