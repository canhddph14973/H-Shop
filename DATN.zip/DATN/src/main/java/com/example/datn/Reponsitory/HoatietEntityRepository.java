package com.example.datn.Reponsitory;

import com.example.datn.Entity.HoatietEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HoatietEntityRepository extends JpaRepository<HoatietEntity, Integer> {
}