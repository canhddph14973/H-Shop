package com.example.datn.Entity;

import jakarta.persistence.*;

import java.sql.Timestamp;

@Entity
@Table(name = "khachhang", schema = "datn", catalog = "")
public class KhachhangEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "Id")
    private int id;
    @Basic
    @Column(name = "TenKhachHang")
    private String tenKhachHang;
    @Basic
    @Column(name = "MatKhauKh")
    private String matKhauKh;
    @Basic
    @Column(name = "SDT")
    private int sdt;
    @Basic
    @Column(name = "GioiTinh")
    private int gioiTinh;
    @Basic
    @Column(name = "Email")
    private String email;
    @Basic
    @Column(name = "IdDiaChi")
    private int idDiaChi;
    @Basic
    @Column(name = "NgayDangKy")
    private Timestamp ngayDangKy;
    @Basic
    @Column(name = "TrangThai")
    private int trangThai;
    @Basic
    @Column(name = "Anh")
    private String anh;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTenKhachHang() {
        return tenKhachHang;
    }

    public void setTenKhachHang(String tenKhachHang) {
        this.tenKhachHang = tenKhachHang;
    }

    public String getMatKhauKh() {
        return matKhauKh;
    }

    public void setMatKhauKh(String matKhauKh) {
        this.matKhauKh = matKhauKh;
    }

    public int getSdt() {
        return sdt;
    }

    public void setSdt(int sdt) {
        this.sdt = sdt;
    }

    public int getGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(int gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getIdDiaChi() {
        return idDiaChi;
    }

    public void setIdDiaChi(int idDiaChi) {
        this.idDiaChi = idDiaChi;
    }

    public Timestamp getNgayDangKy() {
        return ngayDangKy;
    }

    public void setNgayDangKy(Timestamp ngayDangKy) {
        this.ngayDangKy = ngayDangKy;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    public String getAnh() {
        return anh;
    }

    public void setAnh(String anh) {
        this.anh = anh;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        KhachhangEntity that = (KhachhangEntity) o;

        if (id != that.id) return false;
        if (sdt != that.sdt) return false;
        if (gioiTinh != that.gioiTinh) return false;
        if (idDiaChi != that.idDiaChi) return false;
        if (trangThai != that.trangThai) return false;
        if (tenKhachHang != null ? !tenKhachHang.equals(that.tenKhachHang) : that.tenKhachHang != null) return false;
        if (matKhauKh != null ? !matKhauKh.equals(that.matKhauKh) : that.matKhauKh != null) return false;
        if (email != null ? !email.equals(that.email) : that.email != null) return false;
        if (ngayDangKy != null ? !ngayDangKy.equals(that.ngayDangKy) : that.ngayDangKy != null) return false;
        if (anh != null ? !anh.equals(that.anh) : that.anh != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (tenKhachHang != null ? tenKhachHang.hashCode() : 0);
        result = 31 * result + (matKhauKh != null ? matKhauKh.hashCode() : 0);
        result = 31 * result + sdt;
        result = 31 * result + gioiTinh;
        result = 31 * result + (email != null ? email.hashCode() : 0);
        result = 31 * result + idDiaChi;
        result = 31 * result + (ngayDangKy != null ? ngayDangKy.hashCode() : 0);
        result = 31 * result + trangThai;
        result = 31 * result + (anh != null ? anh.hashCode() : 0);
        return result;
    }
}
