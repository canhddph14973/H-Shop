package com.example.datn.Controller;


import com.example.datn.Entity.CoaoEntity;
import com.example.datn.ServiceIpm.CoAoServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@Controller
@RequestMapping("/CoAo")
public class CoAoController {
    @Autowired
    CoAoServiceIpm CoAoServiceIpm;
    @GetMapping("/list")
    public String list(Model model){
        List<CoaoEntity> coao=  CoAoServiceIpm.findAll();
        model.addAttribute("coao",coao);

        return "CoAo/list";
    }
    @GetMapping("/create")
    public String create(Model model){
        CoaoEntity coao =new CoaoEntity();
        model.addAttribute("coao",coao);
        return "CoAo/add";
    }

    @PostMapping("/add")
    public String Add(@ModelAttribute("coao") CoaoEntity coao){
        CoAoServiceIpm.save(coao);
        return "redirect:/CoAo/list";
    }
    @GetMapping("/getId")
    public String getId(Model model,@RequestParam("id") int id  ) {
        Optional<CoaoEntity> coao = CoAoServiceIpm.findById(id);
        if (coao.isPresent()) {
            model.addAttribute("coao", coao.get());
        } else {
            model.addAttribute("coao", new CoaoEntity());
        }
        return "CoAo/update";
    }


    @PostMapping("/update")
    public String update(@ModelAttribute("coao") CoaoEntity coao){
        CoAoServiceIpm.save(coao);
        return "redirect:/CoAo/list";
    }
    @GetMapping("/delete")
    public String deleteId(@RequestParam("id") int id){

        CoAoServiceIpm.deleteById(id);
        return "redirect:/CoAo/list";
    }
}
