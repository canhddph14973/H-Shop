package com.example.datn.Controller;

import com.example.datn.Entity.ThuonghieuEntity;
import com.example.datn.ServiceIpm.ThuongHieuServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@RestController
@RequestMapping("/ThuongHieu")
public class ThuongHieuController {
    @Autowired
    ThuongHieuServiceIpm ThuongHieuServiceIpm;

    @GetMapping("")
    public List<ThuonghieuEntity> list(){
        return ThuongHieuServiceIpm.findAll();
    }

    @PostMapping("")
    public ThuonghieuEntity Add(@RequestBody ThuonghieuEntity ThuonghieuEntity){
        return ThuongHieuServiceIpm.save(ThuonghieuEntity);
    }
    @GetMapping("/{id}")
    public Optional<ThuonghieuEntity> getId(@PathVariable("id") int id ){
        return ThuongHieuServiceIpm.findById(id);
    }
    @PutMapping("/{id}")
    public ThuonghieuEntity update(@PathVariable("id") int id,@RequestBody ThuonghieuEntity ThuonghieuEntity){
        return ThuongHieuServiceIpm.save(ThuonghieuEntity);
    }
    @DeleteMapping("/deleteAnh/{id}")
    public void delete(@PathVariable("id") int id){
        ThuongHieuServiceIpm.deleteById(id);
    }

}
