package com.example.datn.Controller;

import com.example.datn.Entity.SanphamchitietEntity;
import com.example.datn.ServiceIpm.SanPhamChiTietServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@RestController
@RequestMapping("/ SanPhamChiTiet")
public class SanPhamChiTietController {

    @Autowired
    SanPhamChiTietServiceIpm SanPhamChiTietServiceIpm;

    @GetMapping("")
    public List<SanphamchitietEntity> list(){
        return SanPhamChiTietServiceIpm.findAll();
    }

    @PostMapping("")
    public SanphamchitietEntity Add(@RequestBody SanphamchitietEntity SanphamchitietEntity){
        return SanPhamChiTietServiceIpm.save(SanphamchitietEntity);
    }
    @GetMapping("/{id}")
    public Optional<SanphamchitietEntity> getId(@PathVariable("id") int id ){
        return SanPhamChiTietServiceIpm.findById(id);
    }
    @PutMapping("/{id}")
    public SanphamchitietEntity update(@PathVariable("id") int id,@RequestBody SanphamchitietEntity SanphamchitietEntity){
        return SanPhamChiTietServiceIpm.save(SanphamchitietEntity);
    }
    @DeleteMapping("/deleteAnh/{id}")
    public void delete(@PathVariable("id") int id){
        SanPhamChiTietServiceIpm.deleteById(id);
    }

}
