package com.example.datn.service;

import com.example.datn.Entity.TayaoEntity;
import com.example.datn.Reponsitory.TayaoEntityRepository;
import com.example.datn.ServiceIpm.TayAoServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class TayAoService implements TayAoServiceIpm {
    @Autowired
    TayaoEntityRepository TayaoEntityRepository;

    @Override
    public List<TayaoEntity> findAll() {
        return TayaoEntityRepository.findAll();
    }

    @Override
    public List<TayaoEntity> findAllById(Iterable<Integer> integers) {
        return TayaoEntityRepository.findAllById(integers);
    }

    @Override
    public <S extends TayaoEntity> S save(S entity) {
        return TayaoEntityRepository.save(entity);
    }

    @Override
    public Optional<TayaoEntity> findById(Integer integer) {
        return TayaoEntityRepository.findById(integer);
    }

    @Override
    public void deleteById(Integer integer) {
        TayaoEntityRepository.deleteById(integer);
    }
}
