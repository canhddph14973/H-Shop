package com.example.datn.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "tayao", schema = "datn", catalog = "")
public class TayaoEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "Id")
    private int id;
    @Basic
    @Column(name = "TenTayAo")
    private String tenTayAo;
    @Basic
    @Column(name = "Mota")
    private String mota;
    @Basic
    @Column(name = "TrangThai")
    private int trangThai;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTenTayAo() {
        return tenTayAo;
    }

    public void setTenTayAo(String tenTayAo) {
        this.tenTayAo = tenTayAo;
    }

    public String getMota() {
        return mota;
    }

    public void setMota(String mota) {
        this.mota = mota;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TayaoEntity that = (TayaoEntity) o;

        if (id != that.id) return false;
        if (trangThai != that.trangThai) return false;
        if (tenTayAo != null ? !tenTayAo.equals(that.tenTayAo) : that.tenTayAo != null) return false;
        if (mota != null ? !mota.equals(that.mota) : that.mota != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (tenTayAo != null ? tenTayAo.hashCode() : 0);
        result = 31 * result + (mota != null ? mota.hashCode() : 0);
        result = 31 * result + trangThai;
        return result;
    }
}
