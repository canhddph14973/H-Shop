package com.example.datn.Controller;

import com.example.datn.Entity.DangaoEntity;
import com.example.datn.ServiceIpm.DangAoServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@Controller
@RequestMapping("/DangAo")
public class DangAoController {

    @Autowired
    DangAoServiceIpm DangAoServiceIpm;

    @GetMapping("/list")
    public String list(Model model){
        List<DangaoEntity> dangao=  DangAoServiceIpm.findAll();
        model.addAttribute("dangao",dangao);

        return "DangAo/list";
    }
    @GetMapping("/create")
    public String create(Model model){
        DangaoEntity dangao =new DangaoEntity();
        model.addAttribute("dangao",dangao);
        return "DangAo/add";
    }

    @PostMapping("/add")
    public String Add(@ModelAttribute("dangao") DangaoEntity dangao){
        DangAoServiceIpm.save(dangao);
        return "redirect:/DangAo/list";
    }
    @GetMapping("/getId")
    public String getId(Model model,@RequestParam("id") int id  ) {
        Optional<DangaoEntity> dangao = DangAoServiceIpm.findById(id);
        if (dangao.isPresent()) {
            model.addAttribute("dangao", dangao.get());
        } else {
            model.addAttribute("dangao", new DangaoEntity());
        }
        return "DangAo/update";
    }


    @PostMapping("/update")
    public String update(@ModelAttribute("dangao") DangaoEntity dangao){
        DangAoServiceIpm.save(dangao);
        return "redirect:/DangAo/list";
    }
    @GetMapping("/delete")
    public String deleteId(@RequestParam("id") int id){

        DangAoServiceIpm.deleteById(id);
        return "redirect:/DangAo/list";
    }
}

