package com.example.datn.ServiceIpm;

import com.example.datn.Entity.DangaoEntity;

import java.util.List;
import java.util.Optional;

public interface DangAoServiceIpm {
    List<DangaoEntity> findAll();

    List<DangaoEntity> findAllById(Iterable<Integer> integers);

    <S extends DangaoEntity> S save(S entity);

    Optional<DangaoEntity> findById(Integer integer);

    void deleteById(Integer integer);
}
