package com.example.datn.Controller;

import com.example.datn.Entity.KichcoEntity;
import com.example.datn.ServiceIpm.KichCoServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@RestController
@RequestMapping("/KichCo")
public class KichCoController {
    @Autowired
    KichCoServiceIpm KichCoServiceIpm;

    @GetMapping("")
    public List<KichcoEntity> list(){
        return KichCoServiceIpm.findAll();
    }

    @PostMapping("")
    public KichcoEntity Add(@RequestBody KichcoEntity KichcoEntity){
        return KichCoServiceIpm.save(KichcoEntity);
    }
    @GetMapping("/{id}")
    public Optional<KichcoEntity> getId(@PathVariable("id") int id ){
        return KichCoServiceIpm.findById(id);
    }
    @PutMapping("/{id}")
    public KichcoEntity update(@PathVariable("id") int id,@RequestBody KichcoEntity KichcoEntity){
        return KichCoServiceIpm.save(KichcoEntity);
    }
    @DeleteMapping("/deleteAnh/{id}")
    public void delete(@PathVariable("id") int id){
        KichCoServiceIpm.deleteById(id);
    }
}
