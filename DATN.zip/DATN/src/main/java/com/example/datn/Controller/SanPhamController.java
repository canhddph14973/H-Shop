package com.example.datn.Controller;

import com.example.datn.Entity.SanphamEntity;
import com.example.datn.ServiceIpm.SanhamServiceIpm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@RestController
@RequestMapping("/Sanham")
public class SanPhamController {

    @Autowired
    SanhamServiceIpm SanhamServiceIpm;

    @GetMapping("")
    public List<SanphamEntity> list(){
        return SanhamServiceIpm.findAll();
    }

    @PostMapping("")
    public SanphamEntity Add(@RequestBody SanphamEntity SanphamEntity){
        return SanhamServiceIpm.save(SanphamEntity);
    }
    @GetMapping("/{id}")
    public Optional<SanphamEntity> getId(@PathVariable("id") int id ){
        return SanhamServiceIpm.findById(id);
    }
    @PutMapping("/{id}")
    public SanphamEntity update(@PathVariable("id") int id,@RequestBody SanphamEntity SanphamEntity){
        return SanhamServiceIpm.save(SanphamEntity);
    }
    @DeleteMapping("/deleteAnh/{id}")
    public void delete(@PathVariable("id") int id){
        SanhamServiceIpm.deleteById(id);
    }

}
