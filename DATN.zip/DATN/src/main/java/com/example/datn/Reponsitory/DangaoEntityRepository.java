package com.example.datn.Reponsitory;

import com.example.datn.Entity.DangaoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DangaoEntityRepository extends JpaRepository<DangaoEntity, Integer> {
}